function run_pipeline_on_video(video_path)
% run_pipeline_on_video - wrapper to call your pipeline entry point
% Keeps paths + output directories consistent across machines.

setup_paths();

% Determine repo root from this file location:
% ...\repo\app\matlab\main\run_pipeline_on_video.m
this_file  = mfilename('fullpath');
main_dir   = fileparts(this_file);     % ...\app\matlab\main
matlab_dir = fileparts(main_dir);      % ...\app\matlab
app_dir    = fileparts(matlab_dir);    % ...\app
repo_root  = fileparts(app_dir);       % ...\repo

plot_path    = fullfile(repo_root, "outputs", "figs");
trace_folder = fullfile(repo_root, "outputs", "logs");

if ~isfolder(plot_path), mkdir(plot_path); end
if ~isfolder(trace_folder), mkdir(trace_folder); end

% Call YOUR real entry point
iPPG_pipeline_v4(video_path, plot_path, trace_folder, repo_root);
end